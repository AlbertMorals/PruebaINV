﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Inventory.DataAccess
{
    public interface IDataAccess
    {
        List<T>? Consulta<T>(string query, object param, CommandType tipoCommando = CommandType.StoredProcedure);
        Task<List<T>?> ConsultaAsync<T>(string query, object param, CommandType tipoCommando = CommandType.StoredProcedure);
        int Ejecuta(string query, object param, CommandType tipoComando = CommandType.StoredProcedure);
        Task<int> EjecutaAsync(string query, object param, CommandType tipoComando = CommandType.StoredProcedure);
    }
}
