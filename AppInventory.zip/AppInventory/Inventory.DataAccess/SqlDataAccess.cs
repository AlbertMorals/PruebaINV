﻿using Inventory.DataAccess.Context;
using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.DataAccess
{
    public class SqlDataAccess : IDataAccess
    {
        private readonly IDapperContext context;

        public SqlDataAccess(IDapperContext context)
        {
            this.context = context;

        }

        public int Ejecuta(string query, object param, CommandType tipoComando = CommandType.StoredProcedure)
        {
            using SqlConnection cn = (SqlConnection)this.context.CreateConnection;

            return cn.Execute(query, param, commandType: tipoComando);
        }

        public async Task<int> EjecutaAsync(string query, object param, CommandType tipoComando = CommandType.StoredProcedure)
        {
            using SqlConnection cn = (SqlConnection)this.context.CreateConnection;

            return await cn.ExecuteAsync(query, param, commandType: tipoComando);
        }

        public List<T>? Consulta<T>(string query, object param, CommandType tipoCommando = CommandType.StoredProcedure)
        {
            using SqlConnection cn = (SqlConnection)this.context.CreateConnection; 

            var resultado = cn.Query<T>(query, param, commandType: tipoCommando);

            return resultado?.ToList();
        }

        public async Task<List<T>?> ConsultaAsync<T>(string query, object param, CommandType tipoCommando = CommandType.StoredProcedure)
        {

            using SqlConnection cn = (SqlConnection)this.context.CreateConnection; ;

            var resultado = await cn.QueryAsync<T>(query, param, commandType: tipoCommando);

            return resultado?.ToList();
        }
    }
}
