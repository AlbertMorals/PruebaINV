﻿using Inventory.Models;
using Inventory.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Aplication.Aplication
{
    public interface IProductsWebRepository : IRepository<TbProducts>
    {
    }
}
