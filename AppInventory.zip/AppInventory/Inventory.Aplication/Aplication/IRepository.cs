﻿using Inventory.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Aplication.Aplication
{
    public interface IRepository<T> where T : class
    {
        Task<string> AddAsync(T entity);

        List<TbProducts> GetAllSync();

        Task<string> DeleteAsync(Int64 IdProd);

        Task<string> UpdateAsync(T entity);

    }
}
