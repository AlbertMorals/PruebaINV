﻿namespace Inventory.Aplication
{
    public class Class1
    {

    }
}