﻿using Inventory.Aplication.Aplication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Infrastructure.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork(IProductsWebRepository ProductsWebRepository)
        {
            ProductsWeb = ProductsWebRepository;
        }

        public IProductsWebRepository ProductsWeb { get; set; }


    }
}
