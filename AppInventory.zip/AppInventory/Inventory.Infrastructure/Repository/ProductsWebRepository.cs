﻿using Dapper;
using Inventory.Aplication;
using Inventory.Aplication.Aplication;
using Inventory.DataAccess;
using Inventory.Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Infrastructure.Repository
{
    public class ProductsWebRepository : IProductsWebRepository
    {
        private IDataAccess _Context { get; }

        public ProductsWebRepository(IDataAccess context)
        {
            _Context = context;
        }

        public async Task<string> AddAsync(TbProducts entity)
        {
            var paramdata = new
            {
                Name = entity.Name,
                Category = entity.Category,
                Color = entity.Color,
                UnitPrice = entity.UnitPrice,
                AvailableQuantity = entity.AvailableQuantity
            };

            var result = await this._Context.EjecutaAsync("Insert_Product", paramdata);
            return result.ToString();

        }

        public List<TbProducts> GetAllSync()
        {
            var par = new DynamicParameters();
//            par.Add("Ambiente", Ambiente);

            var result = this._Context.Consulta<TbProducts>("ListaProducts", par);
            return result.ToList();

        }

        public async Task<string> DeleteAsync(Int64 IdProd)
        {
            var par = new DynamicParameters();
                     par.Add("ProdId", IdProd);
            var result = await this._Context.EjecutaAsync("DeleteProduct", par);
            return result.ToString();
          
        }

        public async Task<string> UpdateAsync(TbProducts entity)
        {
            var paramdata = new
            {
                ProdId = entity.ProductId,
                Name = entity.Name,
                Category = entity.Category,
                Color = entity.Color,
                UnitPrice = entity.UnitPrice
            };

            var result = await this._Context.EjecutaAsync("UpdateProduct", paramdata);
            return result.ToString();

        }

    }
}
