﻿using Inventory.Aplication.Aplication;
using Inventory.DataAccess.Context;
using Inventory.DataAccess;
using Inventory.Infrastructure.Repository;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Infrastructure
{
    public static class ServiceCollectionExtension
    {
        public static void RegisterServices(this IServiceCollection services, IConfiguration configuracion)
        {
            string connectionString = configuracion.GetConnectionString("DefaultConnection");

            services.AddTransient<IDapperContext, DapperContext>(c => new DapperContext(connectionString));
            services.AddTransient<IDataAccess, SqlDataAccess>();
            services.AddTransient<IProductsWebRepository, ProductsWebRepository>();
            
            services.AddTransient<IUnitOfWork, UnitOfWork>();
        }
    }
}
