﻿namespace Inventory.Infrastructure
{
    public class Class1
    {

    }
}