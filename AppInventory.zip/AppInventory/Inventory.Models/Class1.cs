﻿namespace Inventory.Models
{
    public class Class1
    {

    }
}