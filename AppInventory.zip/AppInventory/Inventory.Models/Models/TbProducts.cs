﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inventory.Models.Models
{
    public class TbProducts
    {
        [Key]
        public int ProductId { get; set; }
        [Required]
        [DataType(DataType.Text)]
        public string Name { get; set; }
        [Required]
        [DataType(DataType.Text)]
        public string Category { get; set; }
        [Required]
        [DataType(DataType.Text)]
        public string Color { get; set; }
        [Required]
        [DataType(DataType.Currency)]
        public decimal UnitPrice { get; set; }
        public int AvailableQuantity { get; set; }
    }
}
