﻿using System;
using Microsoft.AspNetCore.Mvc;
using WebApiExam_API.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using WebApiExam_API.Repository;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using WebApiExam_API.Interfaces;

namespace WebApiExam_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : Controller
    {
        private readonly IWebHostEnvironment _env;
        private readonly IProductsRepository _product;

        public ProductsController(IWebHostEnvironment env, IProductsRepository Product)
        {
            _env = env;
            _product = Product ?? throw new ArgumentNullException(nameof(Product));
        }

        [HttpGet]
        [Route("GetProducts")]
        public async Task<IActionResult> Get()
        {
            return Ok(await _product.GetProducts());
        }


        [HttpPost]
        [Route("AddProduct")]
        public async Task<IActionResult> Post(Products prod)
        {

            var result = await _product.InsertProduct(prod);
            if (result == null)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }

            return Ok("Added Successfully");
        }


        [HttpPut]
        [Route("UpdateProduct")]
        public async Task<IActionResult> Put(Products prod)
        {
            var result = await _product.UpdateProduct(prod);
            if (result == null)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }
            return Ok("Updated Successfully");
        }


        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            var result = _product.DeleteProduct(id);
            return new JsonResult("Deleted Successfully");
        }


        [Route("SaveFile")]
        [HttpPost]
        public JsonResult SaveFile()
        {
            try
            {
                var httpRequest = Request.Form;
                var postedFile = httpRequest.Files[0];
                string filename = postedFile.FileName;
                var physicalPath = _env.ContentRootPath + "/Photos/" + filename;

                using (var stream = new FileStream(physicalPath, FileMode.Create))
                {
                    stream.CopyTo(stream);
                }

                return new JsonResult(filename);
            }
            catch (Exception)
            {
                return new JsonResult("anonymous.png");
            }
        }


       
    }
}
