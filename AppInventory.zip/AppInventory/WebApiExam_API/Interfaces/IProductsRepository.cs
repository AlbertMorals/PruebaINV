﻿using WebApiExam_API.Models;

namespace WebApiExam_API.Interfaces
{
    public interface IProductsRepository
    {
        Task<IEnumerable<Products>> GetProducts();
        Task<Products> GetProductByID(int ID);
        Task<Products> InsertProduct(Products objProduct);
        Task<Products> UpdateProduct(Products objProduct);
        bool DeleteProduct(int ID);
    }
}
