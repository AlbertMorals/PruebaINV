﻿using Microsoft.EntityFrameworkCore;
using WebApiExam_API.Models;

namespace WebApiExam_API.Repository
{
    public class APIDbContext : DbContext
    {
        public APIDbContext(DbContextOptions<APIDbContext> options) : base(options)
        {

        }

        public DbSet<Products> Productos { get; set; }
       
    }
}
