﻿using WebApiExam_API.Models;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using WebApiExam_API.Interfaces;

namespace WebApiExam_API.Repository
{
    public class ProductsRepository : IProductsRepository
    {
        private readonly APIDbContext _appDBContext;

        public ProductsRepository(APIDbContext context)
        {
            _appDBContext = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IEnumerable<Products>> GetProducts()
        {
            return await _appDBContext.Productos.ToListAsync();
        }

        public async Task<Products> GetProductByID(int ID)
        {
            return await _appDBContext.Productos.FindAsync(ID);
        }

        public async Task<Products> InsertProduct(Products objProduct)
        {
            _appDBContext.Productos.Add(objProduct);
            await _appDBContext.SaveChangesAsync();
            return objProduct;
        }

        public async Task<Products> UpdateProduct(Products objProduct)
        {
            _appDBContext.Entry(objProduct).State = EntityState.Modified;
            await _appDBContext.SaveChangesAsync();
            return objProduct;
        }

        public bool DeleteProduct(int ID)
        {
            bool result = false;
            var department = _appDBContext.Productos.Find(ID);
            if (department != null)
            {
                _appDBContext.Entry(department).State = EntityState.Deleted;
                _appDBContext.SaveChanges();
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }
    }
}
