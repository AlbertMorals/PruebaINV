﻿namespace AppInventory.Models
{
    public class ProductsDContext
    {
    }
}
