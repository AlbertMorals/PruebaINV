﻿using Inventory.Aplication.Aplication;
using System.Diagnostics;
using AppInventory.Models;
using Inventory.Models.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace AppInventory.Controllers
{
    public class HomeController : Controller
    { 
        private readonly IConfiguration _config;

        private readonly IUnitOfWork _unitOfWork;

        private readonly ILogger<HomeController> _logger;

        public HomeController(IUnitOfWork unitOfWork, IConfiguration config,ILogger<HomeController> logger)
        {
            _logger = logger;

            _config = config;
            this._unitOfWork = unitOfWork;

        }

        public IActionResult Index()
        {
            List<TbProducts> listProd = new List<TbProducts>();
            TbProducts prod = new TbProducts();

            listProd = _unitOfWork.ProductsWeb.GetAllSync();

            //prod.ProductId = 1;
            //prod.Name = "aceite";
            //prod.Category = "ABARROTES";
            //prod.Color = "amarillo";
            //prod.UnitPrice = 35;
            //prod.AvailableQuantity = 20;
            //listProd.Add(prod);
            return View(listProd);
        }

        public async Task<ActionResult> InsertarProducto(string EntProd)
        {
            List<TbProducts> _List = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TbProducts>>(EntProd);

            TbProducts entityProd = new TbProducts();

      

            foreach (TbProducts row in _List)
            {
                entityProd.Name = row.Name;
                entityProd.Category = row.Category;
                entityProd.Color = row.Color;
                entityProd.UnitPrice = row.UnitPrice;
                entityProd.AvailableQuantity = row.AvailableQuantity;

            }

            ValidationContext validationContext = new ValidationContext(entityProd, null, null);
            List<ValidationResult> errors = new List<ValidationResult>();
            Validator.TryValidateObject(entityProd, validationContext, errors, true);

            string _error = "";

            if (errors.Count() > 0)
            {

                string errorMessages = string.Empty;
                     foreach (var error in errors)
                         {
                             errorMessages += error.ErrorMessage + Environment.NewLine;
                         }
                _error = errorMessages;


                return Json(new { status = "Error", error = _error });
            }
            else
            {
                try
                {
                    var data3 = await _unitOfWork.ProductsWeb.AddAsync(entityProd);
                }
                catch (Exception ex)
                {
                    _error = ex.Message;
                    _logger.LogError(ex.Message);


                }

                if (_error.Length > 0) return Json(new { status = "Error", error = _error });
                else return Json(new { status = "Correcto", error = "" });
            }

        }

        public async Task<ActionResult> ActualizarProducto(string EntProd)
        {
            List<TbProducts> _List = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TbProducts>>(EntProd);

            TbProducts entityProd = new TbProducts();



            foreach (TbProducts row in _List)
            {
                entityProd.ProductId = row.ProductId;
                entityProd.Name = row.Name;
                entityProd.Category = row.Category;
                entityProd.Color = row.Color;
                entityProd.UnitPrice = row.UnitPrice;
                entityProd.AvailableQuantity = row.AvailableQuantity;

            }

            
            string _error = "";

            
            
                try
                {
                    var data3 = await _unitOfWork.ProductsWeb.UpdateAsync(entityProd);
                }
                catch (Exception ex)
                {
                    _error = ex.Message;
                    _logger.LogError(ex.Message);


                }

                if (_error.Length > 0) return Json(new { status = "Error", error = _error });
                else return Json(new { status = "Correcto", error = "" });
            

        }

        public async Task<ActionResult> EliminarProducto(int _IdProd)
        {
           
            string _error = "";


            try
            {
                var data3 = await _unitOfWork.ProductsWeb.DeleteAsync(_IdProd);
            }
            catch (Exception ex)
            {
                _error = ex.Message;
                _logger.LogError(ex.Message);


            }

            if (_error.Length > 0) return Json(new { status = "Error", error = _error });
            else return Json(new { status = "Correcto", error = "" });


        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}