﻿window.ProductsProp = {};


window.Products = {
    Init: function (data) {
        $.extend(ProductsProp, data);

        //$("body").on("click", "#btnbuscar", Param.buscar);
        /*$("body").on("click", "#btndescargar", Log.validaSeleccionados);*/





        //$("body").on("click", "#btncerrar", Products.Cerrar);

        //$("body").on("click", "#btnAgrega", Products.saveParamData(1));
        //btnAgrega

        //Others Initializations
        ProductsProp.formdata = new FormData(); //FormData object

        //Consulta.buscar();


    },
    //Cerrar: function () {
    //    //$("#windModal").modal('hide');
    //    //window.location.href = "Home";
    //},

    saveProductData: function (i, accion) {

        var URLaction = '';
        if (accion == 'update') {
            URLaction = ProductsProp.urlActualiza;
            var txtProductId = i;
            var txtcustName = $("#tblProductsInfo").find("input[id=txtPName_" + i.toString() + "]").val();
            var txtprodcat = $("#tblProductsInfo").find("input[id=txtPPrice_" + i.toString() + "]").val();
            var txtprodcolor = $("#tblProductsInfo").find("input[id=txtPUnit2_" + i.toString() + "]").val();
            var txtprodprecio = $("#tblProductsInfo").find("input[id=txtCDisp_" + i.toString() + "]").val();
            var txtprodcantidad = 0;
        }
        else
        {
            URLaction = ProductsProp.urlInserta;
            var txtProductId = 0;
            var txtcustName = $("#txtprodalta").val();
            var txtprodcat = $("#txtcatalta").val();
            var txtprodcolor = $("#txtcoloralta").val();
            var txtprodprecio = $("#txtprecioalta").val();
            var txtprodcantidad = $("#txtcantidadalta").val();
        }

        var item = {};
        var jsonObj = [];

        
        item["ProductId"] = txtProductId
        item["Name"] = txtcustName;
        item["Category"] = txtprodcat;
        item["Color"] = txtprodcolor;
        item["UnitPrice"] = txtprodprecio;
        item["AvailableQuantity"] = txtprodcantidad;
        jsonObj.push(item);

        var jsonString = JSON.stringify(jsonObj);

        $.ajax({
            url: URLaction,
            type: "POST",
            traditional: true,
            data: { EntProd: jsonString },
            success: function (data) {
                if (data.status == "Correcto") {
                    if (accion == 'update') $("#errorm").text('Se actualizó el producto existosamente.');
                    else $("#errorm").text('Se agrego el nuevo producto al catalogo.');

                }
                else {
                    $("#errorm").text(data.error);
                }
                $("#windModal").modal("show");

                

                setTimeout(delayFunction, 2000);

            }
        });

    },
    Inicio: function () {
        window.location.href = '/';
    },
    //function delayFunction() {

    ////var loc = window.location.href;

    ////window.location.href = "Home";


    //},
    deleteProductData: function (i) {


    $.ajax({
        url: ProductsProp.urlElimina,
        type: "POST",
        traditional: true,
        data: { _IdProd : i },
        success: function (data) {
            if (data.status == "Correcto") {

                $("#errorm").text('Se eliminó correctamente el producto.');

            }
            else {
                $("#errorm").text(data.error);
            }
            $("#windModal").modal("show");

            

            setTimeout(delayFunction, 2000);

        }
    });

    },



}